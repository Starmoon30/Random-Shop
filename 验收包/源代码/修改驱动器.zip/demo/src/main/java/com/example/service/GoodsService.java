package com.example.service;

import com.example.domain.Goods;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 小假
* @description 针对表【Goods】的数据库操作Service
* @createDate 2024-11-03 21:05:15
*/
public interface GoodsService extends IService<Goods> {

}
