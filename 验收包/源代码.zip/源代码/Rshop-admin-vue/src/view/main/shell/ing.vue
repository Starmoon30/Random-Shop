<script setup>

</script>

<template>
  <div>
    已上架
  </div>
</template>

<style scoped>

</style>
