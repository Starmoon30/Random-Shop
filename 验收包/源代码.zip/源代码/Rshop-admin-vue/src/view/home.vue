<script setup>

</script>

<template>
  <div calss="home">
    Home
  </div>
</template>

<style scoped>

</style>
