<script setup>

</script>

<template>
  <div>
    商品管理
  </div>
</template>

<style scoped>

</style>
