<script setup>
  export default {

  }
</script>

<template>
  <div>
    历史上架
  </div>
</template>

<style scoped>

</style>
