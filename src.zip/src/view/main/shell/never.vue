<script setup>

</script>

<template>
  <div>
    预备上架
  </div>
</template>

<style scoped>

</style>
