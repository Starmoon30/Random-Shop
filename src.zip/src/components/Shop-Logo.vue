<script setup>

</script>

<template>
  <!-- Logo 图片 -->
  <div class="logo">
    <img src="@/assets\logo.png" alt="Logo" style="width: 300px; height: 80px"/>
  </div>
</template>

<style scoped>

</style>
